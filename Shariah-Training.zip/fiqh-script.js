let questions=[
{
q:"حكم الصلاة؟",
a:["سنة","واجب","مباح","مكروه"],
c:1
}
];

let i=0;
let score=0;

function start(){
document.getElementById("home").style.display="none";
document.getElementById("exam").style.display="block";
show();
}

function show(){
if(i>=questions.length){
document.getElementById("quiz").innerHTML="انتهى الاختبار";
return;
}

let q=questions[i];

let html="<h3>"+q.q+"</h3>";

q.a.forEach((x,idx)=>{
html+=`<button onclick="ans(${idx})">${x}</button>`;
});

document.getElementById("quiz").innerHTML=html;
}

function ans(x){
if(x===questions[i].c) score++;
i++;
show();
}